Hello World Demo using Document/Literal Style and RSS for Discovery
===================================================================

Yes, it's the ever present Hello World demo.  No product is
complete without one.

Please review the README in the samples directory before
continuing.


The motivation behind this demo is to use RSS as a "cheaper" 
way to "register" Web services and to discover Web services
WSDL.

My hosting an RSS feed that links a title/name to a WSDL, a
client can discover Web services defined in WSDL easily and
cheaply.

The demo retrieves an RSS feed located at the URI defined in
the definition of of running a client in the build.xml. On
reading the feed from the URI the client calls lookup on the 
RSSSRegistry and returns the WSDL that matches the lookup. The
lookup compares the loookup string with each title in the feed.


Prerequisite
------------

If your environment already includes celtix.jar on the
CLASSPATH, and the JDK and ant bin directories on the PATH
it is not necessary to run the environment script described in
the samples directory README.  If your environment is not
properly configured, or if you are planning on using wsdl2java,
javac, and java to build and run the demos, you must set the
environment by running the script.

Download RSSLib4J from here:
http://sourceforge.net/project/showfiles.php?group_id=104845&package_id=112798&release_id=265588

... and place it in the lib directory. That should work.

Somewhere the WSDL from this demo needs to be placed with the
RSS index.xml file on a host that has a web server.

Currently this is already hosted on IPBabble.com and the demo
is configured to use this.


Building and running the demo using ant
---------------------------------------

From the samples/hello_world directory, the ant build script
can be used to build and run the demo.

The build.xml file contains a URL for the RSS Feed instead of
the full path to the WSDL file.

Using either UNIX or Windows:

  ant build
  ant server  (in the background or another window)
  ant client
    

To remove the code generated from the WSDL file and the .class
files, run:

  ant clean



Buildng the demo using wsdl2java and javac
------------------------------------------

From the samples/hello_world directory, first create the target
directory build/classes and then generate code from the WSDL file.

For UNIX:
  mkdir -p build/classes

  wsdl2java -d build/classes ./wsdl/hello_world.wsdl

For Windows:
  mkdir build\classes
    Must use back slashes.

  wsdl2java -d build\classes .\wsdl\hello_world.wsdl
    May use either forward or back slashes.

Now compile both the generated code and the provided client and
server applications with the commands:

  javac -d build/classes src/demo/hw/client/*.java
  javac -d build/classes src/demo/hw/server/*.java

Windows may use either forward or back slashes.



Running the demo using java
---------------------------

From the samples/hello_world directory run the commands, entered on a
single command line:

For UNIX (must use forward slashes):
    java -Djava.util.logging.config.file=$CELTIX_HOME/etc/logging.properties
         demo.hw.server.Server &

    java -Djava.util.logging.config.file=$CELTIX_HOME/etc/logging.properties
         demo.hw.client.Client ./wsdl/hello_world.wsdl

The server process starts in the background.  After running the client,
use the kill command to terminate the server process.

For Windows (may use either forward or back slashes):
  start 
    java -Djava.util.logging.config.file=%CELTIX_HOME%\etc\logging.properties
         demo.hw.server.Server

    java -Djava.util.logging.config.file=%CELTIX_HOME%\etc\logging.properties
       demo.hw.client.Client .\wsdl\hello_world.wsdl

A new command windows opens for the server process.  After running the
client, terminate the server process by issuing Ctrl-C in its command window.

To remove the code generated from the WSDL file and the .class
files, either delete the build directory and its contents or run:

  ant clean
