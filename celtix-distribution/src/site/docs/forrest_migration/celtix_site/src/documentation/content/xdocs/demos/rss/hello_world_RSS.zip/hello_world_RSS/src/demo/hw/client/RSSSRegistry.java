//
//  RSSSRegistry.java
//  
//  A Simple Wrapper on the RSSLib4J. Allows lookup of 
//  a WSDL based on a match with the RSS item title.
//
//  Created by William Henry on 1/5/06.
// 
//

package  demo.hw.client;

import javax.xml.parsers.*;
import java.util.*;
import java.net.URL;
import org.gnu.stealthp.rsslib.*;


public class RSSSRegistry {

    private RSSHandler rsssHandler;
    private RSSChannel rsssch;
    
    public RSSSRegistry (URL feedURL) 
    {
        rsssHandler = new RSSHandler();
        try {
            RSSParser.parseXmlFile(feedURL, rsssHandler, false);
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        
        rsssch = rsssHandler.getRSSChannel();
        System.out.println("[RSSSRegistry] Channel Information:");
        System.out.println(rsssch.toString());
        
        // Should really do some validation to see that the RSS feed is syndicating services
        
    };
    
    public URL lookup( String serviceName)
    {
        System.out.println("\n[RSSSRegistry] Performing Lookup. Searching for " + serviceName);
        LinkedList itemList = rsssch.getItems();
        URL wsdlURL = null;
        try {
            for (int i=0; i < itemList.size(); i++)
            {
                RSSItem itm = (RSSItem)itemList.get(i);
                System.out.println("[RSSSRegistry] RSSSItem Item Title: " + itm.getTitle());
                if ( itm.getTitle().equals(serviceName) )
                {
                    wsdlURL = new URL(itm.getLink());
                    break;
                }
            }
            System.out.println("[RSSSRegistry] WSDL URL Match:" + wsdlURL);       
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
        return wsdlURL; // clean this up
   }
    
}
