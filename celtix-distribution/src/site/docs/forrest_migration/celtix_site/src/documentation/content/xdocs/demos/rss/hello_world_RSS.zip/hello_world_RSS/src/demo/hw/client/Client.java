package demo.hw.client;

import java.io.File;
import java.net.URL;
import javax.xml.namespace.QName;
import org.objectweb.hello_world_soap_http.Greeter;
import org.objectweb.hello_world_soap_http.PingMeFault;
import org.objectweb.hello_world_soap_http.SOAPService;

public final class Client {

    private static final QName SERVICE_NAME 
        = new QName("http://objectweb.org/hello_world_soap_http", "SOAPService");


    private Client() {
    } 

    public static void main(String args[]) throws Exception {
        
        if (args.length == 0) { 
            System.out.println("[Client] Please specify RSS feed");
            System.exit(1); 
        }

        // whenry added the following code to use an RSS feed for lookup
        RSSSRegistry testreg = new RSSSRegistry(new URL(args[0]));
        System.out.print("[Client] Got and parsed feed");
        
        
        URL wsdlURL = testreg.lookup("Hello World");
        // End of whenry code.
        
        System.out.println(wsdlURL);
        SOAPService ss = new SOAPService(wsdlURL, SERVICE_NAME);
        Greeter port = ss.getSoapPort();
        String resp; 

        System.out.println("[Client] Invoking sayHi...");
        resp = port.sayHi();
        System.out.println("[Client] Server responded with: " + resp);
        System.out.println();

        System.out.println("[Client] Invoking greetMe...");
        resp = port.greetMe(System.getProperty("user.name"));
        System.out.println("[Client] Server responded with: " + resp);
        System.out.println();

        System.out.println("[Client] Invoking greetMeOneWay...");
        port.greetMeOneWay(System.getProperty("user.name"));
        System.out.println("[Client] No response from server as method is OneWay");
        System.out.println();

        try {
            System.out.println("[Client] Invoking pingMe, expecting exception...");
            port.pingMe();
        } catch (PingMeFault ex) {
            System.out.println("[Client] Expected exception: PingMeFault has occurred.");
            System.out.println(ex.toString());
        }          
        System.exit(0); 
    }

}