package intalio.integration.client;

import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.math.BigDecimal;
import java.util.GregorianCalendar;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.namespace.QName;
import javax.xml.datatype.XMLGregorianCalendar;

import com.example.WebService;
import com.example.WebServiceService;
import com.intalio.RFQ;
import com.intalio.ContactType;
import com.intalio.BillingType;
import com.intalio.ShippingType;
import com.intalio.LineItemType;
import com.intalio.LineType;

public final class Client {

    private static final QName SERVICE_NAME 
        = new QName("http://www.example.com", "Web_Service_Service");

    private Client() {
    } 

    public static void main(String args[]) throws Exception {
        
        if (args.length == 0) { 
            System.out.println("please specify wsdl");
            System.exit(1); 
        }

        URL wsdlURL;
        File wsdlFile = new File(args[0]);
        if (wsdlFile.exists()) {
            wsdlURL = wsdlFile.toURL();
        } else {
            wsdlURL = new URL(args[0]);
        }

        // create a proxy for the target service
        WebServiceService s = new WebServiceService(wsdlURL, SERVICE_NAME);
        WebService proxy = s.getWebServiceHttpPort();

        // create an instance of the RFQ
        RFQ rfq = new RFQ();

        // initialize the RFQ
        rfq.setRFQNo("1001");

        javax.xml.datatype.DatatypeFactory datatypeFactory = javax.xml.datatype.DatatypeFactory.newInstance();
        XMLGregorianCalendar c = datatypeFactory.newXMLGregorianCalendar(new GregorianCalendar());
        rfq.setDate(c);

        rfq.setCompany("ObjectWeb");

        ContactType contact = new ContactType();
        contact.setFirstName("Harry");
        contact.setLastName("Potter");
        contact.setFax("781-902-8001");
        contact.setPhone("781-902-8000");
        contact.setEmail("harry.potter@objectweb.org");
        rfq.setContactInformation(contact);

        BillingType billing = new BillingType();
        billing.setAddress1("INRIA - ZIRST");
        billing.setAddress2("655 avenue de l'Europe");
        billing.setCity("Montbonnot");
        billing.setState("FRANCE");
        billing.setZip("38334 SAINT-ISMIER Cedex");
        rfq.setBilling(billing);

        ShippingType shipping = new ShippingType();
        shipping.setAddress1("INRIA - ZIRST");
        shipping.setAddress2("655 avenue de l'Europe");
        shipping.setCity("Montbonnot");
        shipping.setState("FRANCE");
        shipping.setZip("38334 SAINT-ISMIER Cedex");
        rfq.setShipping(shipping);

        // populate two line items
        LineItemType lineItems = new LineItemType();
        LineType lt = new LineType();
        lt.setLineNo(1);
        lt.setItemID("1001");
        lt.setDesc("CPU chip");
        lt.setQuantity(new BigDecimal(5));
        lt.setPrice(new BigDecimal(100));
        lt.setTotal(new BigDecimal(500));
        lt.setAvailability("available");
        lineItems.getLine().add(lt);

        LineType lt2 = new LineType();
        lt2.setLineNo(2);
        lt2.setItemID("2001");
        lt2.setDesc("Memory chip");
        lt2.setQuantity(new BigDecimal(15));
        lt2.setPrice(new BigDecimal(20));
        lt2.setTotal(new BigDecimal(300));
        lt2.setAvailability("available");
        lineItems.getLine().add(lt2);
        rfq.setLineItems(lineItems);

        // invoke the receiveRFQ operation
        // this is a oneway operation that kicks off the
        // Intalio|n3 process flow
        System.out.println("Invoking receiveRFQ operation");
        proxy.receiveRFQ(rfq);
        System.out.println("\tOperation complete");


        System.exit(0); 
    }

}