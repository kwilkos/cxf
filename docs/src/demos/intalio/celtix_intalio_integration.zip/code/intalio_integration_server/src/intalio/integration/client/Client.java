package intalio.integration.client;

import java.io.File;
import java.math.BigDecimal;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.xml.ws.Holder;
import javax.xml.namespace.QName;

import com.intalio.StockChecker;
import com.intalio.StockCheckerService;
import com.intalio.LineType;

public final class Client {

    private static final QName SERVICE_NAME 
        = new QName("http://www.example.com", "StockCheckerService");

    private Client() {
    } 

    public static void main(String args[]) throws Exception {
        
        if (args.length == 0) { 
            System.out.println("please specify wsdl");
            System.exit(1); 
        }

        URL wsdlURL;
        File wsdlFile = new File(args[0]);
        if (wsdlFile.exists()) {
            wsdlURL = wsdlFile.toURL();
        } else {
            wsdlURL = new URL(args[0]);
        }

        // create a proxy for the target service
        StockCheckerService s = new StockCheckerService(wsdlURL, SERVICE_NAME);
        StockChecker proxy = s.getStockPort();

        Holder<List<LineType>> items = new Holder<List<LineType>>();
        ArrayList<LineType> list = new ArrayList<LineType>();

        LineType lt = new LineType();
        lt.setLineNo(1);
        lt.setItemID("1001");
        lt.setDesc("CPU chip");
        lt.setQuantity(new BigDecimal(2));
        lt.setPrice(new BigDecimal(100));
        lt.setTotal(new BigDecimal(200));
        lt.setAvailability("available");
        list.add(lt);
        items.value = list;

        // invoke the lineItems operation
        System.out.println("Invoking lineItmes operation");
        proxy.lineItems(items);
        System.out.println("\tOperation returned:");

        System.out.println("\tAvailability: " + items.value.get(0).getAvailability());
        System.out.println("\tNumber: " + items.value.get(0).getQuantity());
        System.out.println("\tTotal: " + items.value.get(0).getTotal());


        System.exit(0); 
    }

}