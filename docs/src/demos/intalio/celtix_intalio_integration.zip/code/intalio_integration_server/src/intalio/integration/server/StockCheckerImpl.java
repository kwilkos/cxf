package intalio.integration.server;

import java.math.BigDecimal;
import java.util.logging.Logger;

import java.util.ArrayList;
import java.util.List;
import javax.xml.ws.Holder;

import com.intalio.LineType;
import com.intalio.StockChecker;


@javax.jws.WebService(name = "StockChecker", serviceName = "StockCheckerService", 
                      targetNamespace = "http://www.intalio.com/", 
                      wsdlLocation = "file:./wsdl/intalio_integration.wsdl")
                  
public class StockCheckerImpl implements StockChecker {

    private static final Logger LOG = 
        Logger.getLogger(StockCheckerImpl.class.getPackage().getName());

    public void lineItems(Holder<List<LineType>> line) {
        List<LineType> lines = line.value;

        if (!lines.isEmpty()) {
            System.out.println("Checking Inventory");
            System.out.println("\tDesired items: ");
            System.out.println("\t\tID: " + lines.get(0).getItemID());
            System.out.println("\t\tDesc.: " + lines.get(0).getDesc());
            System.out.println("\t\tQuantity: " + lines.get(0).getQuantity());
            lines.get(0).setAvailability("not available");
            lines.get(0).setQuantity(new BigDecimal(0));
            lines.get(0).setTotal(new BigDecimal(0));
        } else {
            System.out.println("No content sent in message");
        }
    }
    
}
