<?php

	include("nusoap/lib/nusoap.php");
	include("CONFIG.PHP");

	function getNumbers() {
		global $_WSDL_URL;	
	
		$client = new soapclientw($_WSDL_URL,true);
        	$err = $client->getError();
		if($err) {
                	echo $err.'<br>'.$client->response;
				$result=FALSE;
        	} else {
        		$soap_result = $client->call("getNumbers");
			
			$result=explode(",",$soap_result['responseType']);
		}
		
		return $result;
	}	

	function getZipFromPhone($area,$pre,$num) {
     		$ch = curl_init();

        	curl_setopt($ch,CURLOPT_URL,"www.netsleuth.com/cgi-bin/search/public/phone.cgi?subtype=1&ac=$area&pre=$pre&num=$num&submit=1");
        	curl_setopt($ch,CURLOPT_USERAGENT,"Mozilla/5.001 (windows; U; NT4.0; en-us) Gecko/25250101");
        	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        	$data=curl_exec($ch);

        	preg_match("/[A-Z]{2} ([0-9]{5})/",$data,$match);

		return ($match[1]);

	}

	function getLatLongFromZip($zip) {
		global $_GOOGLE_MAP_KEY;

		$ch=curl_init();
		
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	//	$url = "http://maps.google.com/maps/geo?q=$zip&output=csv&key=ABQIAAAAZTGAyqFcEByAgyhNmDlN6hRLvgY3jGVsKKcHjPMZDesn1p60_RSx60nbXbOI_3dcul5soU3UL_Ct6A";
		$url = "http://maps.google.com/maps/geo?q=$zip&output=csv&key=$_GOOGLE_MAP_KEY";
		
		curl_setopt($ch,CURLOPT_URL,$url);	
		$data=curl_exec($ch);

		$apache_back=explode(",",$data);
		
		$return= array($apache_back[2],$apache_back[3]);

		return $return;
	}


	//Replace this with SOAP call to Celtix
	//$numbers = array("719-488-2242","719-488-2242","719-481-4486","719-550-0895");
	$numbers=getNumbers();

	foreach ($numbers as $thisnumber) {
		$number_split=explode("-",$thisnumber);
		$thiszip = getZipFromPhone($number_split[0],$number_split[1],$number_split[2]);
		
		if(isset($ziplist[$thiszip])) {
			$ziplist[$thiszip]++;
		} else {
			$ziplist[$thiszip]=1;
		}
	}
	header("Content-type: application/xml");
	$xml.='<?xml version="1.0" ?>';
	$xml.='<zip_list>';	
	$zip_id=0;
	foreach (array_keys($ziplist) as $thiszip) {
		$lat_long = getLatLongFromZip($thiszip);
		$zip_code=$thiszip;
		$count=$ziplist[$thiszip];
		$xml.="<zip id=\"$zip_id\">";
		$xml.="<code>$zip_code</code>";
		$xml.="<count>$count</count>";
		$xml.="<lat>$lat_long[0]</lat>";
		$xml.="<long>$lat_long[1]</long>";
		$xml.="</zip>";
		$zip_id++;
	}
	$xml.='</zip_list>';
	echo $xml;
?>

