<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title>The Haute Techno Celtix/Ajax enterprise mashup demo<br>(c) Barry T O'Mahony</title>

    <?php
	include ("CONFIG.PHP");
    ?>

    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=<?=$_GOOGLE_MAP_KEY?>" type="text/javascript"></script>
      
	<script type="text/javascript">
	
	var XML_URL="<?=$_XML_URL?>";

	function load() {
  	if (GBrowserIsCompatible()) {
		var map = new GMap2(document.getElementById("map"));
        	map.addControl(new GSmallMapControl());
        	map.addControl(new GMapTypeControl());
        	 
		var zip_array = [];
		var count_array = [];
		var lat_array = [];
		var long_array = [];

		var XMLResponse = '';
        	
		
        	// Creates a marker at the given point with the given number label
        	function createMarker(point, zip, count) {
          	var marker = new GMarker(point);
         	GEvent.addListener(marker, "click", function() {
            	marker.openInfoWindowHtml("Zip Code:<b>" + zip + "</b> - "+count+' calls');
          	});
          	return marker;
        	}
        	
		
	
		function createRequestObject(){
			var request_o; //declare the variable to hold the object.
			var browser = navigator.appName; //find the browser name
			if(browser == "Microsoft Internet Explorer"){
				/* Create the object using MSIE's method */
				request_o = new ActiveXObject("Microsoft.XMLHTTP");
			}else{
				/* Create the object using other browser's method */
				request_o = new XMLHttpRequest();
			}
			return request_o; //return the object
		}	
		
	
		function getXML(){
			http.open('get', XML_URL );
			http.onreadystatechange = handleXML; 
			http.send(null);
		}
		
	
        function handleXML(){

			if(http.readyState == 4){ //Finished loading the response
       				XMLResponse = http.responseXML;
             	    	var list_of_zips = XMLResponse.getElementsByTagName('zip_list')[0].getElementsByTagName('zip');
                        	
					for (i=0;i<list_of_zips.length;i++) {
             		var child_nodes = list_of_zips[i].childNodes;
                              	
						for(j=0;j<child_nodes.length;j++) {
                               
         	         		if(j%4==0) {
                         		 	zip_array[i]=child_nodes[j].firstChild.nodeValue;
 	                        	} else if(j%4==1) {
    		                         	count_array[i]=child_nodes[j].firstChild.nodeValue;
         	                	} else if(j%4==2) {
             	               	lat_array[i]=child_nodes[j].firstChild.nodeValue;
                 	        	} else {
                             	long_array[i]=child_nodes[j].firstChild.nodeValue;
     	                    	}
         	            	}
                     	}
         		map.setCenter(new GLatLng(lat_array[0],long_array[0]), 7);
         		            	
				for(i=0;i<zip_array.length;i++) {
					var point=new GLatLng(lat_array[i],long_array[i]);
					map.addOverlay(createMarker(point, zip_array[i], count_array[i]));
				}
				
				
               }
		
       		}
       	}
       	var http = createRequestObject();
       	getXML();
     }  		
	

    //]]>
    </script>
  </head>

  <body onload="load()" onunload="GUnload()">
    <div id="map" style="width: 500px; height: 300px"></div>
    <div><font face="arial" size="-1">The Haute Techno Celtix/Ajax enterprise mashup demo<br>(c) Barry T O'Mahony<br></div>
  </body>
</html>

