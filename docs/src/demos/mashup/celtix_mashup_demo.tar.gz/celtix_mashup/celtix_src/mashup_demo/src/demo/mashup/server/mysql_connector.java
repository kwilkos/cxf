import java.sql.*;

public class  mysql_connector
{
	private ResultSet rs; 
	private ResultSet count_rs;

	private int record_count = 0;

	public mysql_connector(String username,String password,String database) {
		try {
			Statement stmt;
			Statement stmt_count;

			Class.forName("com.mysql.jdbc.Driver");
			String url=("jdbc:mysql://localhost:3306/"+database);
			
			Connection con = DriverManager.getConnection(url,username,password);
			
			stmt = con.createStatement();

			rs = stmt.executeQuery("SELECT * FROM calls");


			//MySQL JDBC connector has no record count attribute
			//Why? I dunno, but it means we need to count all the records

			Connection con_count= DriverManager.getConnection(url,username,password);
			stmt_count = con_count.createStatement();
			count_rs = stmt_count.executeQuery("SELECT * FROM calls");

			while(count_rs.next()) {
				record_count++;
			}
			con_count.close();

		} catch (Exception e) {
			e.printStackTrace();
		}	

	}

	public int getRecordCount() {
		return(record_count);
	}

	public int[] getNext() {
		int phone_number[]=new int[3];

		try {	
			if(rs.next()) {
				phone_number[0]=rs.getInt("area_code");
				phone_number[1]=rs.getInt("pre");
				phone_number[2]=rs.getInt("number");
				return(phone_number);
			} else {
				return (null);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return(null);
		}
		
	}
}
