import org.objectweb.mashup_soap_http.NumberQuery;

@javax.jws.WebService(name = "NumberQuery", serviceName = "SOAPService", 
                      targetNamespace = "http://objectweb.org/mashup_soap_http", 
                      wsdlLocation = "file:./wsdl/mashup.wsdl")
                  
public class NumberImpl implements NumberQuery {
    
    /* (non-Javadoc)
     * @see org.objectweb.mashup_soap_http.Number#getNumbers(java.lang.Array)
     */
    public String getNumbers() {
	
	//Return numbers as an array of strings
	//formatted like <area_code>-<pre>-<number>
	//let consumer do with this what it will.
	int this_number[] = new int[3];
	String number_list = "";

	//
	//mysql_connector(username,password,database)
	//Replace these values with the correct values for your server
 	String db_username="username";
	String db_passwd="password";
	String db_name="DB Name";	

	mysql_connector db_connector = new mysql_connector(db_username,db_passwd,db_name);
	
	this_number=db_connector.getNext();

	while (this_number!=null) {
		//Format the number to xxx-xxx-xxxx
		String formatted_number=Integer.toString(this_number[0]);
		formatted_number+="-"+Integer.toString(this_number[1]);
		formatted_number+="-"+Integer.toString(this_number[2]);
		
		//then add it to the comma seperated list
		if(number_list=="") {
			//makes sure we dont start with a comma
			number_list=formatted_number;
		} else {
			number_list=number_list+","+formatted_number;
		}
	
		this_number=db_connector.getNext();
	}

	return number_list;

    }
    
}
