package client;

import java.io.File;
import java.net.URL;

import javax.xml.namespace.QName;
import objectweb.org.celtix.bpel_test.ApproverPT;
import objectweb.org.celtix.bpel_test.ApproverService;
import objectweb.org.celtix.bpel_test.CustomerRequest;

public final class Client {

    private static final QName SERVICE_NAME = 
        new QName("http://org.objectweb/celtix/bpel_test", "ApproverService");


    private Client() {
    } 

    public static void main(String[] args) throws Exception {

        if (args.length == 0) { 
            System.out.println("please specify wsdl");
            System.exit(1); 
        }

        URL wsdlURL;
        File wsdlFile = new File(args[0]);
        if (wsdlFile.exists()) {
            wsdlURL = wsdlFile.toURL();
        } else {
            wsdlURL = new URL(args[0]);
        }
        
        ApproverService service = new ApproverService(wsdlURL, SERVICE_NAME);
        ApproverPT approver = (ApproverPT)service.getSoapPort();

        System.out.println("Invoking approve...");
        CustomerRequest r = new CustomerRequest();
        r.setFirstName("Harry");
        r.setLastName("Potter");
        r.setAmount(14000);
        System.out.println("server responded with: " + approver.approve(r));
        System.out.println(); 



        System.exit(0); 
    }
}
