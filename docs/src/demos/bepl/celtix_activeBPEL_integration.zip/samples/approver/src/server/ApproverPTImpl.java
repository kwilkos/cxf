package server;

import java.util.logging.Logger;
import objectweb.org.celtix.bpel_test.ApproverPT;
import objectweb.org.celtix.bpel_test.ApproverService;
import objectweb.org.celtix.bpel_test.CustomerRequest;

@javax.jws.WebService(name = "ApproverPT", serviceName = "ApproverService", 
                      targetNamespace = "http://org.objectweb/celtix/bpel_test", 
                      wsdlLocation = "file:./wsdl/bpel_test.wsdl")
                  
public class ApproverPTImpl implements ApproverPT {

    private static final Logger LOG = 
        Logger.getLogger(ApproverPTImpl.class.getPackage().getName());
    
    
    public String approve(CustomerRequest in) {
        LOG.info("Executing operation assess");

        System.out.println("approve operation invoked");

        String _return = "yes from approver";
    	if (in.getAmount() > 15000) {
    	    _return = "no from approver";
      }

      return _return;

   } 
}
