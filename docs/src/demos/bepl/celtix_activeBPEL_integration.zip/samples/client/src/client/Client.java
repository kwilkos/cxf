package client;

import java.io.File;
import java.net.URL;

import javax.xml.namespace.QName;
import objectweb.org.celtix.bpel_test.BpelService;
import objectweb.org.celtix.bpel_test.ProcessService;
import objectweb.org.celtix.bpel_test.CustomerRequest;

public final class Client {

    private static final QName SERVICE_NAME = 
        new QName("http://org.objectweb/celtix/bpel_test", "ProcessService");


    private Client() {
    } 

    public static void main(String[] args) throws Exception {

        if (args.length == 0) { 
            System.out.println("please specify wsdl");
            System.exit(1); 
        }

        URL wsdlURL;
        File wsdlFile = new File(args[0]);
        if (wsdlFile.exists()) {
            wsdlURL = wsdlFile.toURL();
        } else {
            wsdlURL = new URL(args[0]);
        }
        
        ProcessService service = new ProcessService(wsdlURL, SERVICE_NAME);
        BpelService bs = (BpelService)service.getProcessServicePort();

        System.out.println("Invoking process...");
        CustomerRequest r = new CustomerRequest();
        r.setFirstName("Harry");
        r.setLastName("Potter");
        r.setAmount(new Integer(args[2]).intValue());
        System.out.println("server responded with: " + bs.process(r));
        System.out.println(); 



        System.exit(0); 
    }
}
