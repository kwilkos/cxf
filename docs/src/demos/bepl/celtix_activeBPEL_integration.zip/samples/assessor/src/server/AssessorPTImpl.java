package server;

import java.util.logging.Logger;
import objectweb.org.celtix.bpel_test.AssessorPT;
import objectweb.org.celtix.bpel_test.AssessorService;
import objectweb.org.celtix.bpel_test.CustomerRequest;

@javax.jws.WebService(name = "AssessorPT", serviceName = "AssessorService", 
                      targetNamespace = "http://org.objectweb/celtix/bpel_test", 
                      wsdlLocation = "file:./wsdl/bpel_test.wsdl")
                  
public class AssessorPTImpl implements AssessorPT {

    private static final Logger LOG = 
        Logger.getLogger(AssessorPTImpl.class.getPackage().getName());
    
    
    public String assess(CustomerRequest in) {
        LOG.info("Executing operation assess");

        System.out.println("assess operation invoked");
        String _return = "low";
    	if (in.getAmount() > 8000) {
    	    _return = "high";
      }

      return _return;

   } 
}
